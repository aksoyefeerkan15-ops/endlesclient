package com.example.mixin; // Kendi paket adını koru

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(ChatHud.class)
public class ChatHudMixin {

    @ModifyVariable(
        method = "addMessage(Lnet/minecraft/text/Text;)V",
        at = @At("HEAD"),
        argsOnly = true
    )
    private Text addDragonIconAfterName(Text message) {
        if (message == null) return message;

        // Modu çalıştıran oyuncunun kullanıcı adını otomatik alır
        String localPlayerName = MinecraftClient.getInstance().getSession().getUsername();
        String messageContent = message.getString();

        // Eğer mesaj senin ismini içeriyorsa
        if (messageContent.contains(localPlayerName)) {
            // İsminin sağ tarafına (arkasına) ejderha ikonunu ekler
            String updatedText = messageContent.replace(localPlayerName, localPlayerName + " \uE000");
            return Text.literal(updatedText);
        }

        return message;
    }
}